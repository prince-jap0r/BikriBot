"use client";

import type { Customer, DeliveryZone, Order, Product, Stats } from "@/lib/repo/types";

export interface Overview {
  pageId: string;
  pages: {
    page_id: string;
    shop_name: string;
    agent_name: string;
    shop_info: string;
    is_active: boolean;
    has_token: boolean;
  }[];
  stats: Stats;
  orders: Order[];
  products: Product[];
  customers: Customer[];
  zones: DeliveryZone[];
  setup: {
    dbDriver: string;
    aiProvider: string;
    defaultModel: string;
    fallbackModel: string;
    aiKeySet: boolean;
    fbPageIdSet: boolean;
    fbPageTokenSet: boolean;
    fbVerifyTokenSet: boolean;
    fbAppSecretSet: boolean;
    signatureVerification: boolean;
    webhookPath: string;
  };
}

export async function apiCall<T>(
  secret: string,
  url: string,
  init?: { method?: string; body?: unknown },
): Promise<{ ok: boolean; status: number; data: T & { error?: string } }> {
  const res = await fetch(url, {
    method: init?.method ?? "GET",
    headers: { "Content-Type": "application/json", "x-admin-secret": secret },
    body: init?.body ? JSON.stringify(init.body) : undefined,
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  return { ok: res.ok, status: res.status, data };
}
