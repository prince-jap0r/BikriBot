import { z } from "zod";
import { cleanPageId, requireAdmin } from "@/lib/admin-auth";
import { getRepo } from "@/lib/repo";

export const dynamic = "force-dynamic";

const Body = z.object({
  pageId: z.string().optional(),
  orderId: z.string().uuid(),
  status: z.enum(["pending", "confirmed", "shipped", "delivered", "cancelled"]),
});

export async function PATCH(req: Request) {
  const denied = requireAdmin(req);
  if (denied) return denied;
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Invalid body" }, { status: 400 });
  const repo = await getRepo();
  await repo.updateOrderStatus(cleanPageId(parsed.data.pageId), parsed.data.orderId, parsed.data.status);
  return Response.json({ ok: true });
}
