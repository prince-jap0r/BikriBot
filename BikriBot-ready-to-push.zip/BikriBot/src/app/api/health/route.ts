import { getRepo } from "@/lib/repo";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const repo = await getRepo();
    const ok = await repo.ping();
    return Response.json({ ok, driver: repo.driver }, { status: ok ? 200 : 500 });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
