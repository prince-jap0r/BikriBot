import { tool } from "ai";
import { z } from "zod";
import { appConfig } from "@/config/app.config";
import { isUuid, matchDeliveryZone, normalizeBdPhone, searchProductList } from "@/lib/commerce";
import type { Customer, Repo } from "@/lib/repo/types";

export interface ToolContext {
  repo: Repo;
  pageId: string;
  customer: Customer;
  /** Set by createOrder so the orchestrator knows the stage moved to "ordered". */
  state: { orderPlaced: boolean; orderNo?: string };
}

function money(n: number): string {
  return `${n}${appConfig.currency}`;
}

/**
 * All tools are bound to ONE tenant (pageId) and ONE customer. The model can never pass a
 * pageId/customerId, and prices/stock/delivery charge are always re-read from the database.
 */
export function createTools(ctx: ToolContext) {
  const { repo, pageId, customer, state } = ctx;

  return {
    searchProducts: tool({
      description:
        "প্রোডাক্ট খুঁজে নাম, দাম, স্টক ও আইডি দেয়। দাম/স্টক বলার আগে অবশ্যই এটি কল করো। ফাঁকা query দিলে সাধারণ তালিকা আসে।",
      inputSchema: z.object({
        query: z.string().max(100).describe("প্রোডাক্টের নাম/ক্যাটাগরি/কীওয়ার্ড, যেমন 'পাঞ্জাবি'"),
      }),
      execute: async ({ query }) => {
        try {
          const all = await repo.listProducts(pageId);
          const found = searchProductList(all, query, 5);
          return {
            count: found.length,
            products: found.map((p) => ({
              productId: p.id,
              name: p.name,
              price: p.price,
              stock: p.stock,
              inStock: p.stock > 0,
              category: p.category,
              details: p.description.slice(0, 120),
            })),
            note: found.length === 0 ? "কোনো মিল পাওয়া যায়নি, কিছু বানিয়ে বলবে না।" : undefined,
          };
        } catch (e) {
          console.error("[tool:searchProducts]", e);
          return { count: 0, products: [], error: "LOOKUP_FAILED" };
        }
      },
    }),

    checkStock: tool({
      description: "নির্দিষ্ট প্রোডাক্টের চাহিদার পরিমাণ স্টকে আছে কি না যাচাই করে (অর্ডার কনফার্মের আগে)।",
      inputSchema: z.object({
        productId: z.string().describe("searchProducts থেকে পাওয়া productId"),
        quantity: z.number().int().min(1).max(50).default(1),
      }),
      execute: async ({ productId, quantity }) => {
        try {
          if (!isUuid(productId)) return { ok: false, error: "PRODUCT_NOT_FOUND" };
          const all = await repo.listProducts(pageId);
          const p = all.find((x) => x.id === productId);
          if (!p) return { ok: false, error: "PRODUCT_NOT_FOUND" };
          return {
            ok: true,
            name: p.name,
            unitPrice: p.price,
            available: p.stock,
            enough: p.stock >= quantity,
            lineTotal: p.price * quantity,
          };
        } catch (e) {
          console.error("[tool:checkStock]", e);
          return { ok: false, error: "LOOKUP_FAILED" };
        }
      },
    }),

    getDeliveryCharge: tool({
      description: "কাস্টমারের ঠিকানা/এলাকা অনুযায়ী ডেলিভারি চার্জ ও আনুমানিক সময় জানায়।",
      inputSchema: z.object({
        address: z.string().min(2).max(300).describe("এলাকা বা পূর্ণ ঠিকানা"),
      }),
      execute: async ({ address }) => {
        try {
          const zones = await repo.getDeliveryZones(pageId);
          const m = matchDeliveryZone(zones, address);
          if (!m) return { ok: false, error: "NO_ZONE_CONFIGURED" };
          return {
            ok: true,
            zone: m.zone.name,
            charge: m.zone.charge,
            eta: m.zone.eta,
            matchedBy: m.matchedKeyword,
          };
        } catch (e) {
          console.error("[tool:getDeliveryCharge]", e);
          return { ok: false, error: "LOOKUP_FAILED" };
        }
      },
    }),

    createOrder: tool({
      description:
        "অর্ডার সেভ করে। শুধু তখনই কল করো যখন নাম, ফোন, পূর্ণ ঠিকানা ও প্রোডাক্ট নিশ্চিত এবং কাস্টমার শেষ সারাংশে স্পষ্ট সম্মতি দিয়েছে।",
      inputSchema: z.object({
        name: z.string().min(2).max(80),
        phone: z.string().min(10).max(20).describe("বাংলাদেশি মোবাইল নম্বর"),
        address: z.string().min(8).max(300).describe("পূর্ণ ঠিকানা"),
        items: z
          .array(
            z.object({
              productId: z.string(),
              quantity: z.number().int().min(1).max(20),
            }),
          )
          .min(1)
          .max(10),
        note: z.string().max(200).optional().describe("সাইজ/কালার বা বিশেষ নির্দেশনা"),
      }),
      execute: async ({ name, phone, address, items, note }) => {
        try {
          if (state.orderPlaced) {
            // The same turn already created an order: never create a second one.
            return { ok: false, error: "ORDER_ALREADY_PLACED_THIS_TURN", orderNo: state.orderNo };
          }
          const normalized = normalizeBdPhone(phone);
          if (!normalized) return { ok: false, error: "INVALID_PHONE" };
          if (items.some((i) => !isUuid(i.productId))) return { ok: false, error: "PRODUCT_NOT_FOUND" };

          // Merge duplicate lines of the same product.
          const merged = new Map<string, number>();
          for (const i of items) merged.set(i.productId, (merged.get(i.productId) ?? 0) + i.quantity);

          // Delivery charge is computed server-side from the address – never trusted from the model.
          const zones = await repo.getDeliveryZones(pageId);
          const zone = matchDeliveryZone(zones, address);

          const result = await repo.createOrder({
            page_id: pageId,
            customer_id: customer.id,
            name: name.trim(),
            phone: normalized,
            address: address.trim(),
            items: [...merged.entries()].map(([product_id, qty]) => ({ product_id, qty })),
            delivery_charge: zone?.zone.charge ?? 0,
            note: note ?? null,
          });

          if (!result.ok) return result;

          state.orderPlaced = true;
          state.orderNo = result.order_no;

          // Deterministic bookkeeping (does not depend on the LLM).
          const summary = result.items.map((i) => `${i.name} x${i.qty}`).join(", ");
          await repo.updateCustomer(customer.id, {
            name: name.trim(),
            phone: normalized,
            stage: "ordered",
          });
          if (!result.duplicate) {
            const mem = await repo.getMemory(customer.id);
            await repo.upsertMemory({
              customer_id: customer.id,
              page_id: pageId,
              summary: mem?.summary ?? "",
              preferences: mem?.preferences ?? {},
              last_address: address.trim(),
              last_order_summary: `${result.order_no}: ${summary} (${money(result.total)})`,
              total_orders: (mem?.total_orders ?? 0) + 1,
            });
          }

          return {
            ok: true,
            duplicate: result.duplicate,
            orderNo: result.order_no,
            items: result.items.map((i) => ({ name: i.name, qty: i.qty, unitPrice: i.unit_price })),
            subtotal: result.subtotal,
            deliveryCharge: result.delivery_charge,
            total: result.total,
            deliveryEta: zone?.zone.eta ?? "",
          };
        } catch (e) {
          console.error("[tool:createOrder]", e);
          return { ok: false, error: "ORDER_FAILED" };
        }
      },
    }),
  };
}

export type BikribotTools = ReturnType<typeof createTools>;
