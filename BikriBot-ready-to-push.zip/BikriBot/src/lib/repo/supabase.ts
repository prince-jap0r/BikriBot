import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type {
  ChatMessage,
  CreateOrderInput,
  CreateOrderResult,
  Customer,
  CustomerPatch,
  DeliveryZone,
  Memory,
  Order,
  PageRow,
  Product,
  ProductInput,
  Repo,
  Stats,
} from "./types";

function unwrap<T>(res: { data: T | null; error: { message: string; code?: string } | null }): T {
  if (res.error) throw new Error(`Supabase: ${res.error.message}`);
  return res.data as T;
}

export function createSupabaseRepo(): Repo {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required");

  const sb: SupabaseClient = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  return {
    driver: "supabase",

    async ping() {
      const { error } = await sb.from("pages").select("page_id", { head: true, count: "exact" });
      return !error;
    },

    async getPage(pageId) {
      const res = await sb.from("pages").select("*").eq("page_id", pageId).maybeSingle();
      return unwrap<PageRow | null>(res);
    },

    async listPages() {
      const res = await sb.from("pages").select("*").order("created_at");
      return unwrap<PageRow[]>(res);
    },

    async upsertPage(page) {
      unwrap(await sb.from("pages").upsert(page, { onConflict: "page_id" }));
    },

    async getOrCreateCustomer(pageId, psid) {
      const find = async () =>
        unwrap<Customer | null>(
          await sb.from("customers").select("*").eq("page_id", pageId).eq("psid", psid).maybeSingle(),
        );
      const existing = await find();
      if (existing) return existing;
      const ins = await sb.from("customers").insert({ page_id: pageId, psid }).select("*").single();
      if (ins.error) {
        // Race: another request created it first.
        const again = await find();
        if (again) return again;
        throw new Error(`Supabase: ${ins.error.message}`);
      }
      return ins.data as Customer;
    },

    async updateCustomer(customerId, patch: CustomerPatch) {
      if (Object.keys(patch).length === 0) return;
      unwrap(await sb.from("customers").update(patch).eq("id", customerId));
    },

    async listCustomers(pageId, limit) {
      const res = await sb
        .from("customers")
        .select("*")
        .eq("page_id", pageId)
        .order("last_message_at", { ascending: false })
        .limit(limit);
      return unwrap<Customer[]>(res);
    },

    async recordMessage(pageId, customerId, role, content, fbMid) {
      const ins = await sb.from("messages").insert({
        page_id: pageId,
        customer_id: customerId,
        role,
        content,
        fb_mid: fbMid ?? null,
      });
      if (ins.error) {
        if (ins.error.code === "23505") return false; // duplicate mid
        throw new Error(`Supabase: ${ins.error.message}`);
      }
      await sb.from("customers").update({ last_message_at: new Date().toISOString() }).eq("id", customerId);
      return true;
    },

    async recentMessages(customerId, limit) {
      const res = await sb
        .from("messages")
        .select("role, content, created_at")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false })
        .limit(limit);
      return unwrap<ChatMessage[]>(res).reverse();
    },

    async getMemory(customerId) {
      const res = await sb.from("customer_memories").select("*").eq("customer_id", customerId).maybeSingle();
      return unwrap<Memory | null>(res);
    },

    async upsertMemory(memory) {
      unwrap(
        await sb
          .from("customer_memories")
          .upsert({ ...memory, updated_at: new Date().toISOString() }, { onConflict: "customer_id" }),
      );
    },

    async listProducts(pageId, opts) {
      let q = sb.from("products").select("*").eq("page_id", pageId);
      if (!opts?.includeInactive) q = q.eq("is_active", true);
      const res = await q.order("created_at").limit(500);
      return unwrap<Product[]>(res);
    },

    async upsertProduct(pageId, p: ProductInput) {
      const row = {
        page_id: pageId,
        sku: p.sku ?? null,
        name: p.name,
        description: p.description ?? "",
        category: p.category ?? "",
        price: p.price,
        stock: p.stock,
        is_active: p.is_active ?? true,
      };
      if (p.id) {
        unwrap(await sb.from("products").update(row).eq("id", p.id).eq("page_id", pageId));
      } else {
        unwrap(await sb.from("products").insert(row));
      }
    },

    async getDeliveryZones(pageId) {
      const res = await sb.from("delivery_zones").select("*").eq("page_id", pageId).order("charge");
      return unwrap<DeliveryZone[]>(res);
    },

    async createOrder(input: CreateOrderInput) {
      const res = await sb.rpc("bikribot_create_order", {
        p_page_id: input.page_id,
        p_customer_id: input.customer_id,
        p_name: input.name,
        p_phone: input.phone,
        p_address: input.address,
        p_items: input.items,
        p_delivery_charge: input.delivery_charge,
        p_note: input.note ?? null,
      });
      return unwrap<CreateOrderResult>(res);
    },

    async listOrders(pageId, limit) {
      const res = await sb
        .from("orders")
        .select("*")
        .eq("page_id", pageId)
        .order("created_at", { ascending: false })
        .limit(limit);
      return unwrap<Order[]>(res);
    },

    async updateOrderStatus(pageId, orderId, status) {
      unwrap(await sb.from("orders").update({ status }).eq("id", orderId).eq("page_id", pageId));
    },

    async stats(pageId): Promise<Stats> {
      const count = async (table: string) => {
        const { count: c } = await sb
          .from(table)
          .select("*", { count: "exact", head: true })
          .eq("page_id", pageId);
        return c ?? 0;
      };
      const [customers, messages, orders, products] = await Promise.all([
        count("customers"),
        count("messages"),
        count("orders"),
        count("products"),
      ]);
      const rev = await sb
        .from("orders")
        .select("total")
        .eq("page_id", pageId)
        .neq("status", "cancelled")
        .limit(5000);
      const revenue = ((rev.data as { total: number }[] | null) ?? []).reduce((s, r) => s + r.total, 0);
      return { customers, messages, orders, revenue, products };
    },
  };
}
