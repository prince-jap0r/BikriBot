/** General application configuration (non-Facebook, non-AI). */

export type DbDriver = "supabase" | "postgres";

export function resolveDbDriver(): DbDriver {
  const forced = (process.env.DB_DRIVER || "").toLowerCase();
  if (forced === "supabase" || forced === "postgres") return forced;
  // Supabase is the primary store. Local Postgres is only a fallback for sandboxes/dev.
  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) return "supabase";
  return "postgres";
}

export const appConfig = {
  /** Secret for the admin dashboard + test chat API (sent as `x-admin-secret`). */
  get adminSecret(): string {
    return process.env.ADMIN_SECRET || "";
  },
  /** Used when a page has no custom shop name. */
  defaultShopName: process.env.DEFAULT_SHOP_NAME || "আমাদের শপ",
  currency: process.env.CURRENCY_SYMBOL || "৳",
  /** Webhook dedup / safety. */
  maxIncomingChars: 1500,
};
