-- BikriBot schema (idempotent). Run in Supabase → SQL Editor.
-- All tables are tenant-scoped by page_id. RLS is enabled with NO policies:
-- only the server (service role key) can read/write. Never expose the service key to the browser.

create table if not exists pages (
  page_id text primary key,
  shop_name text not null default 'আমাদের শপ',
  agent_name text not null default 'রাহি',
  shop_info text not null default '',
  page_access_token text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  page_id text not null,
  sku text,
  name text not null,
  description text not null default '',
  category text not null default '',
  price integer not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists products_page_sku_uq on products (page_id, sku);
create index if not exists products_page_idx on products (page_id);

create table if not exists delivery_zones (
  id uuid primary key default gen_random_uuid(),
  page_id text not null,
  name text not null,
  keywords text[] not null default '{}',
  charge integer not null check (charge >= 0),
  eta text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists delivery_zones_page_idx on delivery_zones (page_id);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  page_id text not null,
  psid text not null,
  name text,
  phone text,
  stage text not null default 'greeting',
  psych_type text not null default 'unknown',
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);
create unique index if not exists customers_page_psid_uq on customers (page_id, psid);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  page_id text not null,
  customer_id uuid not null references customers(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  fb_mid text,
  created_at timestamptz not null default now()
);
create index if not exists messages_customer_idx on messages (customer_id, created_at desc);
create unique index if not exists messages_page_mid_uq on messages (page_id, fb_mid) where fb_mid is not null;

create table if not exists customer_memories (
  customer_id uuid primary key references customers(id) on delete cascade,
  page_id text not null,
  summary text not null default '',
  preferences jsonb not null default '{}'::jsonb,
  last_address text,
  last_order_summary text,
  total_orders integer not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  page_id text not null,
  customer_id uuid references customers(id) on delete set null,
  customer_name text not null,
  phone text not null,
  address text not null,
  items jsonb not null,
  items_hash text not null default '',
  subtotal integer not null,
  delivery_charge integer not null default 0,
  total integer not null,
  status text not null default 'pending',
  note text,
  created_at timestamptz not null default now()
);
create index if not exists orders_page_idx on orders (page_id, created_at desc);
create index if not exists orders_customer_idx on orders (customer_id, items_hash);

alter table pages enable row level security;
alter table products enable row level security;
alter table delivery_zones enable row level security;
alter table customers enable row level security;
alter table messages enable row level security;
alter table customer_memories enable row level security;
alter table orders enable row level security;

-- Atomic order creation: locks product rows, validates stock + price from DB, decrements stock,
-- inserts the order. De-duplicates identical orders from the same customer within 10 minutes.
create or replace function bikribot_create_order(
  p_page_id text,
  p_customer_id uuid,
  p_name text,
  p_phone text,
  p_address text,
  p_items jsonb,
  p_delivery_charge integer,
  p_note text default null
) returns jsonb
language plpgsql
as $$
declare
  v_item jsonb;
  v_prod products%rowtype;
  v_qty integer;
  v_lines jsonb := '[]'::jsonb;
  v_subtotal integer := 0;
  v_hash text;
  v_existing orders%rowtype;
  v_order orders%rowtype;
begin
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    return jsonb_build_object('ok', false, 'error', 'NO_ITEMS');
  end if;

  select md5(string_agg((e.value->>'product_id') || ':' || (e.value->>'qty'), ',' order by (e.value->>'product_id')))
    into v_hash
    from jsonb_array_elements(p_items) as e;

  select * into v_existing
    from orders
   where page_id = p_page_id
     and customer_id = p_customer_id
     and items_hash = v_hash
     and created_at > now() - interval '10 minutes'
   order by created_at desc
   limit 1;
  if found then
    return jsonb_build_object(
      'ok', true, 'duplicate', true,
      'order_id', v_existing.id, 'order_no', v_existing.order_no,
      'subtotal', v_existing.subtotal, 'delivery_charge', v_existing.delivery_charge,
      'total', v_existing.total, 'items', v_existing.items
    );
  end if;

  -- Pass 1: lock (sorted to avoid deadlocks) + validate. No writes yet.
  for v_item in
    select e.value from jsonb_array_elements(p_items) as e order by e.value->>'product_id'
  loop
    v_qty := greatest((v_item->>'qty')::integer, 1);
    select * into v_prod
      from products
     where id = (v_item->>'product_id')::uuid and page_id = p_page_id and is_active
       for update;
    if not found then
      return jsonb_build_object('ok', false, 'error', 'PRODUCT_NOT_FOUND', 'product_id', v_item->>'product_id');
    end if;
    if v_prod.stock < v_qty then
      return jsonb_build_object('ok', false, 'error', 'OUT_OF_STOCK', 'product', v_prod.name, 'available', v_prod.stock);
    end if;
  end loop;

  -- Pass 2: apply.
  for v_item in
    select e.value from jsonb_array_elements(p_items) as e order by e.value->>'product_id'
  loop
    v_qty := greatest((v_item->>'qty')::integer, 1);
    select * into v_prod from products where id = (v_item->>'product_id')::uuid and page_id = p_page_id;
    update products set stock = stock - v_qty where id = v_prod.id;
    v_lines := v_lines || jsonb_build_array(jsonb_build_object(
      'product_id', v_prod.id, 'name', v_prod.name, 'qty', v_qty, 'unit_price', v_prod.price
    ));
    v_subtotal := v_subtotal + v_prod.price * v_qty;
  end loop;

  insert into orders (
    order_no, page_id, customer_id, customer_name, phone, address,
    items, items_hash, subtotal, delivery_charge, total, status, note
  ) values (
    'BB-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 5)),
    p_page_id, p_customer_id, p_name, p_phone, p_address,
    v_lines, v_hash, v_subtotal, greatest(p_delivery_charge, 0), v_subtotal + greatest(p_delivery_charge, 0), 'pending', p_note
  ) returning * into v_order;

  return jsonb_build_object(
    'ok', true, 'duplicate', false,
    'order_id', v_order.id, 'order_no', v_order.order_no,
    'subtotal', v_order.subtotal, 'delivery_charge', v_order.delivery_charge,
    'total', v_order.total, 'items', v_order.items
  );
end;
$$;

-- ───────────── Demo seed (safe to re-run) ─────────────
insert into pages (page_id, shop_name, agent_name, shop_info)
values (
  'demo', 'ডেমো ফ্যাশন', 'রাহি',
  'পেমেন্ট: ক্যাশ অন ডেলিভারি, বিকাশ/নগদ। রিটার্ন: ৩ দিনের মধ্যে সাইজ/ডিফেক্ট সমস্যায় এক্সচেঞ্জ।'
) on conflict (page_id) do nothing;

insert into products (page_id, sku, name, description, category, price, stock) values
  ('demo', 'PJ-001', 'কটন পাঞ্জাবি (সাদা)', 'প্রিমিয়াম কটন, সাইজ M/L/XL, ঈদ কালেকশন', 'পাঞ্জাবি', 1450, 25),
  ('demo', 'PJ-002', 'কটন পাঞ্জাবি (নেভি ব্লু)', 'প্রিমিয়াম কটন, সাইজ M/L/XL', 'পাঞ্জাবি', 1550, 12),
  ('demo', 'SR-001', 'জামদানি শাড়ি (লাল)', 'হাতে বোনা জামদানি, ব্লাউজ পিস সহ', 'শাড়ি', 4800, 5),
  ('demo', 'SN-001', 'ক্যাজুয়াল স্নিকার্স', 'হালকা ও আরামদায়ক, সাইজ ৩৯-৪৪', 'জুতা', 2200, 0),
  ('demo', 'TS-001', 'ড্রপ শোল্ডার টি-শার্ট', 'কটন, ইউনিসেক্স, সাইজ S/M/L/XL', 'টি-শার্ট', 650, 60)
on conflict do nothing;

insert into delivery_zones (page_id, name, keywords, charge, eta)
select 'demo', 'ঢাকা সিটি', array['ঢাকা','dhaka','মিরপুর','ধানমন্ডি','উত্তরা','গুলশান','মোহাম্মদপুর','মতিঝিল','বনানী'], 60, '১-২ দিন'
where not exists (select 1 from delivery_zones where page_id = 'demo' and name = 'ঢাকা সিটি');

insert into delivery_zones (page_id, name, keywords, charge, eta)
select 'demo', 'ঢাকার বাইরে', '{}', 120, '৩-৫ দিন'
where not exists (select 1 from delivery_zones where page_id = 'demo' and name = 'ঢাকার বাইরে');
