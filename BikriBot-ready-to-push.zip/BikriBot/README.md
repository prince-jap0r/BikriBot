# 🤖 BikriBot – Facebook Page Sales AI Agent

মাল্টি-টেন্যান্ট Facebook Messenger সেলস এজেন্ট। Next.js (App Router, TypeScript) · Vercel AI SDK (`ai` v7) · OpenRouter (প্রোভাইডার পরিবর্তনযোগ্য) · Supabase · Vercel Hobby-ফ্রেন্ডলি।

## ফাইল স্ট্রাকচার

```
prompts/            core.md psych.md flow.md db.md memory.md   ← স্টেজ অনুযায়ী ডাইনামিক লোড
supabase/schema.sql টেবিল + অ্যাটমিক অর্ডার ফাংশন + ডেমো সিড
src/config/         facebook.config.ts  ai.config.ts  app.config.ts
src/lib/ai/         provider · prompt-loader · tools · agent · memory-updater
src/lib/facebook/   graph · signature · splitter
src/lib/repo/       Supabase (প্রাইমারি) + লোকাল Postgres (ডেভ ফলব্যাক)
src/app/api/        webhook/facebook · chat · admin/* · health
```

## সেটআপ (ধাপে ধাপে)

1. **Supabase**: নতুন প্রজেক্ট খুলে *SQL Editor*-এ `supabase/schema.sql` পুরোটা Run করুন। (RLS চালু; শুধু সার্ভার `service_role` কী দিয়ে অ্যাক্সেস হয়।)
2. **Env**: `.env.example` কপি করে `.env.local` বানান এবং পূরণ করুন
   (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `OPENROUTER_API_KEY`, `FB_*`, `ADMIN_SECRET`)।
3. **Meta App**: Messenger প্রোডাক্ট যোগ করুন → Webhooks → Callback URL
   `https://<your-domain>/api/webhook/facebook`, Verify Token = `FB_VERIFY_TOKEN`; Subscribe: `messages`, `messaging_postbacks`। App Secret → `FB_APP_SECRET`।
4. **পেজ যোগ**: অ্যাডমিন UI (`/`) → সেটআপ → Page ID, শপ নাম, এজেন্টের নাম, শপ তথ্য ও Page Access Token দিন
   (অথবা সিঙ্গেল-পেজের জন্য `FB_PAGE_ID` + `FB_PAGE_ACCESS_TOKEN`)। টোকেন কখনো ব্রাউজারে ফেরত আসে না।
5. **প্রোডাক্ট ও ডেলিভারি জোন**: UI-এর "প্রোডাক্ট" ট্যাবে প্রোডাক্ট দিন। ডেলিভারি জোন `delivery_zones` টেবিলে
   (`keywords` খালি থাকলে সেটি "ডিফল্ট" জোন)। টেস্ট চ্যাট ট্যাবে ফেসবুক ছাড়াই এজেন্ট পরীক্ষা করুন।
6. **Vercel ডিপ্লয়**: রিপো ইমপোর্ট করে Environment Variables বসান → Deploy। `after()` + `maxDuration = 60` ব্যবহার হয়েছে, তাই Hobby প্ল্যানে ওয়েবহুক সাথে সাথে `200` দেয়।

## প্রোভাইডার/মডেল বদল (কোড না ছুঁয়ে)

| লক্ষ্য | env |
|---|---|
| মডেল বদল | `AI_DEFAULT_MODEL`, `AI_FALLBACK_MODEL` |
| OpenAI সরাসরি | `AI_PROVIDER=openai`, `OPENAI_API_KEY`, মডেল `gpt-4o-mini` |
| Gemini | `AI_PROVIDER=gemini`, `GEMINI_API_KEY`, মডেল `gemini-2.0-flash` |
| Anthropic | `AI_PROVIDER=anthropic`, `ANTHROPIC_API_KEY`, মডেল `claude-…` |
| অন্য যেকোনো OpenAI-compatible | `AI_PROVIDER=custom`, `CUSTOM_AI_BASE_URL`, `CUSTOM_AI_API_KEY` |

## টোকেন অপ্টিমাইজেশন

`core.md` ও `flow.md` সবসময় · `psych.md` শুধু product/objection/closing স্টেজে বা আপত্তির কথায় · `db.md` প্রোডাক্ট/অর্ডার ইনটেন্টে ·
`memory.md` শুধু রিটার্নিং কাস্টমারে (এর "State template" অংশ মডেলকে পাঠানো হয় না, মেমরি `memory-updater.ts` আলাদাভাবে আপডেট করে)।
শপের নাম ও এজেন্টের নাম আলাদা "বর্তমান তথ্য" ব্লকে যায়। কোনো prompt ফাইলে `## [stage:xxx]` / `## [psych:xxx]` সেকশন যোগ করলে লোডার
সেগুলো স্বয়ংক্রিয়ভাবে বেছে নেবে। হিস্ট্রি শেষ ১২ মেসেজ, আউটপুট ক্যাপ ৪০০ টোকেন।
`psych_type` মান: `unknown | price | quality | trust | unsure | ready`।
টেস্ট চ্যাটে প্রতিটি উত্তরের নিচে লোড হওয়া মডিউল ও আনুমানিক টোকেন দেখা যায়।

## নিরাপত্তা ও নির্ভুলতা

- `X-Hub-Signature-256` (HMAC, raw body) যাচাই; Graph API টোকেন URL-এ নয়, `Authorization` হেডারে।
- ওয়েবহুক রিট্রাই ডিডুপ (`mid` ইউনিক ইনডেক্স)।
- দাম/স্টক/ডেলিভারি চার্জ শুধু DB থেকে; `createOrder` সার্ভারে দাম, স্টক ও ফোন যাচাই করে এবং `bikribot_create_order` ফাংশনে অ্যাটমিকভাবে স্টক কমায় (ওভারসেল ও ডুপ্লিকেট অর্ডার প্রতিরোধ)।
- `/api/chat` ও `/api/admin/*` `x-admin-secret` (`ADMIN_SECRET`) ছাড়া বন্ধ।
- এজেন্ট নিজে থেকে AI পরিচয় প্রকাশ করে না, তবে কেউ আন্তরিকভাবে জিজ্ঞেস করলে মিথ্যা বলে না (Meta পলিসি ও আস্থার জন্য)।

## লোকাল ডেভ

Supabase env না থাকলে `DATABASE_URL` (লোকাল Postgres) ব্যবহার হয় এবং `supabase/schema.sql` প্রথম ব্যবহারে অটো-অ্যাপ্লাই হয়।

```bash
npm install && npm run dev
```
